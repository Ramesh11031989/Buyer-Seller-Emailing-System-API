Cpanel Create Emails with php
=============

These files acompany the tutorial: [Cpanel Create Emails with php](https://daveismyname.com/cpanel-create-emails-with-php-bp)
